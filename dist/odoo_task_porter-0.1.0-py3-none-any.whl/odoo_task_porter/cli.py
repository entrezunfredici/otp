"""Compatibility shim for legacy imports."""
from __future__ import annotations

import sys

from odoo_task_porter.cli import main

__all__ = ["main"]


if __name__ == "__main__":
    sys.exit(main())
